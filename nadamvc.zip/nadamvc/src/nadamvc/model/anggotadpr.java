package nadamvc.model;

    private Integer nama;
    private String jabatan;
    private String jk;
    private String alamat;
public class anggotadpr {
   private Integer nama;
    private String jabatan;
    private String jk;
    private String alamat;

    public Integer getNama() {
        return nama;
    }

    public void setNama(Integer nama) {
        this.nama = nama;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public String getJk() {
        return jk;
    }

    public void setJk(String jk) {
        this.jk = jk;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

   

}
